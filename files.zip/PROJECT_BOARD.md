# 📊 TDK Projekt: Nyomonkövetési Tábla

## 🎯 Projekt Fázisok és Feladatok

### **FÁZIS 1: TERVEZÉS & ADATGYŰJTÉS** (1–2. hét)
_Meghatározzuk a projekt kereit és biztosítjuk az alapadatokat_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 1.1 | Pilot terület kiválasztása (A vagy B opció) | 🔴 TODO | Te | Hét vége | [Pilot_terulet_valasztas.md](00_PLANNING/Pilot_terulet_valasztas.md) |
| 1.2 | Konzulensek felkutatása & rákérdezés | 🔴 TODO | Te | 1.5 hét | Informatika + vízügy |
| 1.3 | Copernicus GLO-30 DEM letöltése | 🔴 TODO | Te | 1.5 hét | [OpenTopography](https://cloud.sdsc.edu) vagy Copernicus portal |
| 1.4 | Lechner DDM5 hozzáférési kérelem (ha szükséges) | 🔴 TODO | Te | 1.5 hét | Konzulensen keresztül igényelni |
| 1.5 | CORINE Land Cover réteg | 🔴 TODO | Te | 2 hét | Copernicus data space, ingyenes |
| 1.6 | VTT-tározók helyadatai (OVF) | 🔴 TODO | Te | 2 hét | Validációhoz szükséges |
| 1.7 | Talaj-adatok (AGROTOPO/DOSZTIK) | 🔴 TODO | Te | 2 hét | Beszivárgás → alkalmassági pontszám |
| 1.8 | Történelmi térképek (MAPIRE/Arcanum) | 🔴 TODO | Te | 2 hét | XVIII–XIX. sz. mocsarak = extra validáció |

**Célok a fázis végén:**
- ✅ Pilot terület = jól definiált, kezelhető (ideális: 500–2000 km²)
- ✅ Összes szükséges adat letöltve és az `01_DATA/` mappában tárolva
- ✅ QGIS projektfájl a pilot terület határai megrajzolva

---

### **FÁZIS 2: FEJLESZTÉSI KÖRNYEZET** (3. hét)
_Eszközök telepítése, projekt inicializálása_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 2.1 | Python 3.10+ + Anaconda/venv telepítés | 🔴 TODO | Te | 3.0 | [Python_setup.md](07_DOCS/Python_setup.md) |
| 2.2 | Szükséges könyvtárak (rasterio, numpy, scipy, geopandas, WhiteboxTools, deap) | 🔴 TODO | Te | 3.1 | requirements.txt fájl |
| 2.3 | QGIS 3.28+ telepítés | 🔴 TODO | Te | 3.1 | Vizualizáció, ellenőrzés |
| 2.4 | Git repo inicializálása (GitHub) | 🔴 TODO | Te | 3.2 | .gitignore: nagy fájlok kizárása |
| 2.5 | Mappastruktúra létrehozása | 🔴 TODO | Te | 3.2 | Git commit: "Initial project structure" |
| 2.6 | Tesztelés: egyetlen DEM-pixel feldolgozása Python-ban | 🔴 TODO | Te | 3.3 | Szimpla rasterio teszt |

**Célok a fázis végén:**
- ✅ Minden fejlesztési eszköz működik
- ✅ Git repo aktív, első commit
- ✅ Python HelloWorld: "DEM beolvasás működik"

---

### **FÁZIS 3: ADATFELDOLGOZÁS (LOWER LEVEL)** (4–5. hét)
_DEM előkészítés, terepelemzés – kész algoritmusok alkalmazása_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 3.1 | DEM vetületi átalakítása EOV-ba (EPSG:23700) | 🔴 TODO | Te | 4.0 | Kritkus! A pixelméret hiba nélkül |
| 3.2 | DEM vágása pilot terület határára (Clip raster by mask) | 🔴 TODO | Te | 4.1 | QGIS vagy Python (rasterio) |
| 3.3 | Fill algoritmus (hamis mélyedések kitöltése) | 🔴 TODO | Te | 4.2 | WhiteboxTools: wbt.fill_depressions() |
| 3.4 | Lejtés (slope) számítása | 🔴 TODO | Te | 4.3 | scipy.ndimage vagy WhiteboxTools |
| 3.5 | Lefolyásirányt (flow direction) & akkumuláció | 🔴 TODO | Te | 4.3 | Kész WhiteboxTools algoritmus |
| 3.6 | Topográfiai nedvességi index (TWI) | 🔴 TODO | Te | 4.4 | ln(akk. / tan(slope)) |
| 3.7 | Ellenőrzés: QGIS-ben vizuálisan megjelenítés | 🔴 TODO | Te | 4.4 | Nézd meg: értelmes-e az eredmény? |

**Kód:** `02_PROCESSING/01_dem_preprocessing.py`, `02_PROCESSING/02_terep_analiza.py`

**Célok a fázis végén:**
- ✅ Előfeldolgozott DEM Magyarország ETR-89 / EOV-ban (EPSG:23700)
- ✅ Slope, flow direction, TWI raszterek mentve
- ✅ Vizuálisan értelmes térképek QGIS-ben

---

### **FÁZIS 4: TÉRFOGAT-ANALÍZIS (HÖGER-SZINT ALGORITMUS)** (5. hét)
_Első saját algoritmus: "Hol lehet víz tárolódni?"_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 4.1 | Mélyedés-térfogat számítás | 🔴 TODO | Te | 5.0 | mélyedés = kitöltött − eredeti DEM |
| 4.2 | Pixel → m³ konverzió (terület × mélység) | 🔴 TODO | Te | 5.1 | Vigyázz: 30m pixel = 900 m², nem az összes fájlnak ez az értéke! |
| 4.3 | Összefüggő mélyedések klaszterezése (scipy.ndimage.label) | 🔴 TODO | Te | 5.1 | Minden "tó" = egy klaszter |
| 4.4 | Medencék topológiájának meghatározása (melyik melyikbe folyik?) | 🔴 TODO | Te | 5.2 | Opcionális, de érdekes |
| 4.5 | Térfogat-térkép exportálása GeoTIFF-ként | 🔴 TODO | Te | 5.2 | `03_OPTIMIZATION/` mappában |
| 4.6 | Első publikálható eredmény: "Ahol lehet vizet tárolni" térkép | 🔴 TODO | Te | 5.3 | Ez már egy TDK-figura! |

**Kód:** `02_PROCESSING/03_melyedes_analiza.py`

**Célok a fázis végén:**
- ✅ Melyedés-térfogat térkép (GeoTIFF) + PNG exportálás
- ✅ Statisztika: max, átlag, medián térfogat
- ✅ "Top 50 természetes medence" lista CSV-ben

---

### **FÁZIS 5: ALKALMASSÁGI MODELL (MCDA + AHP)** (6–7. hét)
_Többszempontú döntéshozatal: nem csak térfogat, hanem "jósága"_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 5.1 | Kritériumok listázása | 🔴 TODO | Te | 6.0 | Pl.: térfogat, távolság vízfolyástól, talaj, védelem |
| 5.2 | AHP párosítási mátrix felépítése | 🔴 TODO | Te | 6.1 | Saaty 1-9 skálája, majd sajátvektor = súlyok |
| 5.3 | Minden kritérium raszter normalizálása (0–1) | 🔴 TODO | Te | 6.2 | Min–max normalizálás |
| 5.4 | Távolság vízfolyástól (Euclidean, flow-based?) | 🔴 TODO | Te | 6.2 | scipy.ndimage.distance_transform_edt |
| 5.5 | Talaj-beszivárgás beintegrálása | 🔴 TODO | Te | 6.3 | AGROTOPO rétegből vagy poligonizálva |
| 5.6 | Védettség maszkja (védett területek = 0) | 🔴 TODO | Te | 6.3 | CORINE-ből vagy OVF-ből |
| 5.7 | Végső alkalmassági térkép: Σ wᵢ · rétegᵢ | 🔴 TODO | Te | 6.4 | Ez lesz az optimalizálás inputja |
| 5.8 | Alkalmassági scores validálása: elég van "jó" hely? | 🔴 TODO | Te | 6.4 | Ha mindenki <0.3, gond van |

**Kód:** `03_OPTIMIZATION/04_alkalmassagi_modell.py`

**Célok a fázis végén:**
- ✅ Alkalmassági térkép (0–1 skála) + PNG
- ✅ AHP-mátrix dokumentálva (függelékben)
- ✅ Top 100–200 "jó" helyszín azonosítva

---

### **FÁZIS 6: OPTIMALIZÁLÁS – GREEDY & GENETIKUS** (7–8. hét)
_Az informatika magja: melyik kombinációt válasszuk?_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 6.1 | Greedy (mohó) algoritmus prototípusa | 🔴 TODO | Te | 7.0 | Mindig a legjobb arány; O(n log n) |
| 6.2 | Greedy futtatása pilot területre | 🔴 TODO | Te | 7.1 | Benchmark: futásidő, megoldás minősége |
| 6.3 | Genetikus algoritmus szkelet (DEAP vagy saját) | 🔴 TODO | Te | 7.2 | Populáció, szelekció, kereszt, mutáció |
| 6.4 | Genetikus futtatása: populáció=50, generáció=100 | 🔴 TODO | Te | 7.3 | Benchmark: konvergencia grafikon |
| 6.5 | Greedy vs. GA összehasonlítása | 🔴 TODO | Te | 7.4 | Táblázat: térfogat, költség, futásidő |
| 6.6 | Érzékenységi analízis: mi történik, ha a költségvetés ±20%? | 🔴 TODO | Te | 7.4 | Opcionális, de nagyon jó TDK-pont |
| 6.7 | Végső javasolt helyszín-lista (rangsorolt) | 🔴 TODO | Te | 8.0 | CSV: ID, név, térfogat, alkalmassági pont, algoritmus |

**Kód:** `03_OPTIMIZATION/05_greedy_optimizer.py`, `06_genetic_optimizer.py`, `optimizer_comparison.py`

**Célok a fázis végén:**
- ✅ Greedy + GA eredmények összehasonlítva
- ✅ "Opt 1" (GA javasolt helyszínek) térkép
- ✅ Futásidő-elemzés, konvergencia grafikon

---

### **FÁZIS 7: VALIDÁCIÓ** (9. hét)
_"Igaza van-e az algoritmusnak a valóságban?"_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 7.1 | Vásárhelyi-terv (VTT) tározók pontos helye térképen | 🔴 TODO | Te | 9.0 | OVF-ből vagy VTT-ből közvetlenül |
| 7.2 | Algoritmus javaslatai vs. valós VTT-tározók | 🔴 TODO | Te | 9.1 | Átfedés? Alternatív helyek? |
| 7.3 | XVIII–XIX. századi mocsár-térkép (MAPIRE) digitalizálása | 🔴 TODO | Te | 9.2 | Történelmi mélyedések = mai mélyedések? |
| 7.4 | Történelmi vs. algoritmikus mélyedések korrelációja | 🔴 TODO | Te | 9.3 | Hány % egyezik? |
| 7.5 | Validációs jelentés: összefoglalás, erősségek, gyengeségek | 🔴 TODO | Te | 9.4 | Ez lesz a Megvitatás része |

**Kód:** `04_VALIDATION/validate_vs_VTT.py`, `validate_vs_historic.py`

**Célok a fázis végén:**
- ✅ Validációs térképek (algoritmus + VTT + történelmi)
- ✅ Statisztikai összehasonlítás (például: Jaccard-index)
- ✅ Erős, tényellenőrzött kutatási nóta

---

### **FÁZIS 8: VIZUALIZÁCIÓ & INTERAKTÍV MEGJELENÍTÉS** (9–10. hét)
_A végeredmény szép megjelenítése_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 8.1 | PNG térképek: DEM, alkalmassági, javasolt helyszínek | 🔴 TODO | Te | 10.0 | matplotlib vagy QGIS export |
| 8.2 | Interaktív folium-térkép (zoom, rétegek, popupok) | 🔴 TODO | Te | 10.1 | HTML output: egy kattintás a böngészőben |
| 8.3 | Dashboard: grafikonok (térfogat-eloszlás, algoritmus-összehasonlítás) | 🔴 TODO | Te | 10.2 | Matplotlib vagy plotly |
| 8.4 | Végeredmény-prezentáció: Jupyter notebook (opcional) | 🔴 TODO | Te | 10.3 | Reprodukálható, interaktív végig-futás |

**Kód:** `05_VISUALIZATION/make_maps.py`, `interactive_map.py`, `results_dashboard.html`

**Célok a fázis végén:**
- ✅ Prezentációra kész térképek
- ✅ Interaktív térkép a TDK-védés bemutatójában

---

### **FÁZIS 9: DOLGOZAT ÍRÁSA** (10–12. hét)
_A tudományos szöveg_

| # | Feladat | Státusz | Felelős | Határidő | Megjegyzés |
|---|---------|---------|---------|----------|-----------|
| 9.1 | Kivonat (fél oldal, magyar + angol) | 🔴 TODO | Te | 10.0 | Utolsónak írj! |
| 9.2 | Bevezetés: Alföld, aszály, VTT kontextusa | 🔴 TODO | Te | 10.2 | Motiváció, célkitűzés (1–2 oldal) |
| 9.3 | Irodalmi áttekintés: GIS-MCDA, hazai vízstratégia, genetics alg. | 🔴 TODO | Te | 10.4 | 3–5 oldal, szakirodalom |
| 9.4 | Anyag és módszer: 8 lépés + pszeudokód | 🔴 TODO | Te | 11.0 | Részletes, reprodukálható (5–8 oldal) |
| 9.5 | Eredmények: térképek, táblázatok, GA vs. greedy | 🔴 TODO | Te | 11.2 | 4–6 oldal + melléklete |
| 9.6 | Megvitatás: validáció, korlátok, javaslatok | 🔴 TODO | Te | 11.4 | Honnan véd a dolgozat, mit nem? (3–4 oldal) |
| 9.7 | Következtetések | 🔴 TODO | Te | 11.4 | Lezárás, jövő irányok (1 oldal) |
| 9.8 | Irodalomjegyzék + függelékek (kód link) | 🔴 TODO | Te | 11.4 | GitHub URL |
| 9.9 | Végső szerkesztés, helyesírás-ellenőrzés | 🔴 TODO | Te | 12.0 | PDF kész |

**Kód:** `06_DOLGOZAT/` mappa, markdown-fájlok

**Célok a fázis végén:**
- ✅ Teljes, szerkesztett TDK-dolgozat PDF-ben
- ✅ Nyomtatható verzió

---

## 📈 Ütemezési Irányelv

**Ajánlott naptár** (szeptembertől kezdve):

| Hét | Fázis | Főbb mérföldkövek |
|-----|-------|-------------------|
| 1–2 | TERVEZÉS | Pilot terület + adatok ✅ |
| 3 |환境 | Eszközök + Git + teszt ✅ |
| 4–5 | ADATFELDOLGOZÁS | DEM + terepelemzés ✅ |
| 6 | TÉRFOGAT | Első saját algoritmus ✅ |
| 7–8 | OPTIMALIZÁLÁS | Greedy + GA, összehasonlítás ✅ |
| 9 | VALIDÁCIÓ | VTT + történelmi ✅ |
| 10 | VIZUALIZÁCIÓ | Térképek, interaktív megjelenítés ✅ |
| 11–12 | DOLGOZAT | Írás, szerkesztés, végleges verzió ✅ |

**Puffer:** 2 hét extra a váratlan nehézségekhez (adat-hibák, algoritmus-debug, konzulens-visszajelzés).

---

## 🚨 Kritikus Pontok (Ne hagyj figyelmen kívül!)

1. **EOV-vetület:** DEM-et EOV-ba kell transzformálni! Hibás vetület = minden távolság- és terület-számítás rossz.
2. **Fill algoritmus:** Hamis mélyedések torzítják az eredményt. Ezt nem szabad kihagyni!
3. **AHP súlyozás:** Dokumentáld precízen — a bírálók nézni fogják.
4. **Saját algoritmus:** A greedy és GA implementációja **kell, hogy saját kódod legyen** — ez adja az érték nagy részét.
5. **Validáció:** Ez az, ami megkülönböztet téged más GIS-munkáktól — hangsúlyozd!
6. **GitHub:** Kód elérhető, verziókezelés = profi benyomás.

---

## 📞 Checkpoint Jelölések

Minden fázis végén szánj időt a bírálatra:
- ✅ = Terv szerint halad
- 🟡 = Kis késedelem, de kezelni lehet
- 🔴 = Blokkoló probléma — konzulenshez!

---

**Utolsó frissítés:** 2026.08.18
