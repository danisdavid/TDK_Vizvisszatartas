# TDK Projekt: Vízvisszatartási műtárgyak algoritmikus helyszín-optimalizálása az Alföldön

## 📋 Projekt Áttekintés

**Téma:** Vízvisszatartási műtárgyak algoritmikus helyszín-optimalizálása az Alföldön digitális domborzatmodell alapján

**Cél:** Egy Python-alapú szoftver és TDK dolgozat, amely automatikusan azonosít és rangsorol vízvisszatartó létesítmények potenciális helyeit az Alföldi vízgyűjtőkön, aszálykompenzáció céljából.

**Státusz:** 🟡 Projekt inicializálása

---

## 🎯 Projekt Magja

### A Probléma
- Az Alföld súlyosan sérülékeny a vízdeficittel szemben (2022, 2025 aszályok)
- Folyószabályozás után elveszett a természetes vízvisszatartó képesség
- Szükség van algoritmikus módszerre a megfelelő helyszínek azonosítására

### A Megoldás
- **Input:** Digitális domborzatmodell (DEM) + kiegészítő adatok
- **Process:** Python-alapú, többszempontú optimalizálás (MCDA + genetikus algoritmus)
- **Output:** Rangsorolt helyszínlista + interaktív térképek

---

## 📁 Mappastruktúra

```
TDK_Vizvisszatartas/
├── README.md                    # Ez a fájl
├── PROJECT_BOARD.md            # Projekt nyomonkövetés (lépések, határidők)
├── METODOLOGIA.md              # Részletes módszertani leírás (8 lépés)
├── IRODALOM.md                 # Irodalomkutatási lista és hivatkozások
│
├── 00_PLANNING/
│   ├── Pilot_terulet_valasztas.md
│   ├── Adatforrasok.md
│   └── Konzulens_kontaktok.md
│
├── 01_DATA/
│   ├── DEM/                    # Domborzatmodellek (raw)
│   │   ├── README.md
│   │   └── .gitignore
│   ├── Kiegeszito_reteget/    # Talaj, földhasználat, stb.
│   │   ├── CORINE/
│   │   └── OVF_vizhalozat/
│   └── VTT_referencia/         # Validációs referencia (Vásárhelyi-terv)
│
├── 02_PROCESSING/
│   ├── 01_dem_preprocessing.py      # Fill, mindig meg kell futni
│   ├── 02_terep_analiza.py          # Slope, flow, TWI
│   ├── 03_melyedes_analiza.py       # Térfogat-számítás
│   └── config.py                    # Paraméterek, elérési utak
│
├── 03_OPTIMIZATION/
│   ├── 04_alkalmassagi_modell.py    # MCDA, AHP súlyozás
│   ├── 05_greedy_optimizer.py       # Mohó heurisztika
│   ├── 06_genetic_optimizer.py      # Genetikus algoritmus
│   └── optimizer_comparison.py      # Összehasonlítás
│
├── 04_VALIDATION/
│   ├── validate_vs_VTT.py           # Validáció Vásárhelyi-tervvel
│   ├── validate_vs_historic.py      # Validáció XVIII–XIX. századi térképekkel
│   └── validation_report.md         # Eredmények
│
├── 05_VISUALIZATION/
│   ├── make_maps.py                 # Térképek QGIS/matplotlib-hez
│   ├── interactive_map.py           # Folium-alapú interaktív térkép
│   └── results_dashboard.html       # HTML végeredmény
│
├── 06_DOLGOZAT/
│   ├── 00_Kivonat.md
│   ├── 01_Bevezetes.md
│   ├── 02_Irodalmi_attekintes.md
│   ├── 03_Anyag_es_modszer.md
│   ├── 04_Eredmenyek.md
│   ├── 05_Megvitatas.md
│   ├── 06_Kovetkeztetesek.md
│   ├── 07_Irodalomjegyzek.md
│   └── 08_Melekletek.md
│
├── 07_DOCS/
│   ├── DEM_utmutato.md         # Hogyan tölts le/feldolgozz DEM-et
│   ├── QGIS_workflow.md        # QGIS lépések egyenként
│   ├── Python_setup.md         # Környezet telepítése
│   └── FAQ.md                  # Gyakori kérdések
│
└── .gitignore                   # Git (nagy fájlok kizárása)
```

---

## 🚀 Következő Lépések

### 1. **Pilot terület kiválasztása** (1. hét)
   - [ ] Tisza-menti vízgyűjtő (A opció) vagy Duna–Tisza köze (B opció)?
   - [ ] Szökőkör: Hármas-Körös vagy Hortobágy–Berettyó

### 2. **Adatgyűjtés** (1–2. hét)
   - [ ] Copernicus GLO-30 DEM letöltés
   - [ ] CORINE réteg beszerzése
   - [ ] VTT-tározók pontos helyeinek szerzése (OVF)

### 3. **Fejlesztési környezet** (3. hét)
   - [ ] Python, QGIS, könyvtárak telepítése
   - [ ] Git repo inicializálása

### 4. **Az első Python modulok** (4–5. hét)
   - [ ] DEM-előfeldolgozás (fill algoritmus)
   - [ ] Terepelemzés (slope, flow)

### 5. **Az alkalmassági és optimalizálási magkernel** (6–8. hét)
   - [ ] AHP súlyozás
   - [ ] Greedy és genetikus algoritmusok

### 6. **Validáció** (9. hét)
   - [ ] VTT-összehasonlítás
   - [ ] Történelmi térképek elemzése

### 7. **Dolgozat írása** (10–12. hét)
   - [ ] Módszertan
   - [ ] Eredmények, megvitatás
   - [ ] Végső szerkesztés

---

## 📚 Dokumentumok ebben a Projektben

- **[METODOLOGIA.md](METODOLOGIA.md)** – A teljes 8-lépéses módszertan részletezése
- **[PROJECT_BOARD.md](PROJECT_BOARD.md)** – Nyomonkövetendő feladatok, határidők
- **[IRODALOM.md](IRODALOM.md)** – Szükséges szakirodalom és források

---

## 💡 Gyors Emlékeztetők

✅ **Lényeg:** Nem QGIS-gombnyomás, hanem **saját Python-algoritmusok** = a TDK értéke
✅ **Validáció:** VTT + történelmi térképek = erős érv a dolgozat mellett
✅ **Pilot terület:** Egy jól kidolgozott kis terület > egész Alföld felszínesen
✅ **Verziókezelés:** Git-től az elejétől – professzionális benyomást kelt

---

## 🤝 Konzulens & Támogatás

- **Informatikai témavetető:** [név, e-mail] – algoritmus, Python
- **Vízügyi konzulens:** [név] – OVF vagy egyetemi tanszék – domain tudás
- **GitHub:** [link] – kód megosztása, verziókezelés

---

**Utolsó frissítés:** 2026.08.18
**Készült:** Projekt inicializáláskor
