# 📘 Módszertani Leírás – Vízvisszatartási Műtárgyak Algoritmikus Optimalizálása

## 🎯 Áttekintés

Ez a dokumentum a **teljes 8 lépéses folyamatot** írja le részletesen, pszeudokóddal, kritikus pontokkal és hibalehetőségekkel.

**Szerkezzet:**
1. Adatgyűjtés
2. DEM előfeldolgozás (hamis mélyedések kitöltése)
3. Terepelemzés (lejtés, lefolyás, nedvességi index)
4. Térfogat-analízis (melyik pixelekbe lehet vizet tárolni)
5. Alkalmassági modell (MCDA + AHP súlyozás)
6. Algoritmikus optimalizálás (Greedy + Genetikus algoritmus)
7. Validáció (Vásárhelyi-terv, történelmi térképek)
8. Végeredmény és vizualizáció

---

## 1️⃣ ADATGYŰJTÉS

### Szükséges Adatok

| Adat | Forrás | Formátum | Kritikus | Megjegyzés |
|------|--------|----------|----------|-----------|
| **Digitális domborzatmodell (DEM)** | Copernicus GLO-30 vagy Lechner DDM5 | GeoTIFF | ✅ | Az egész projekt alapja |
| **Domborzat-vetület** | EOV (EPSG:23700) | Koordináta-rendszer | ✅ | Hibás vetület = összes hosszú-, terület-számítás rossz |
| **Vízfolyások** | OVF, Hydrosheds | Vektor (vonal) | ✅ | Melyik pixelből lehet vizet szedni |
| **Talaj beszivárgása** | AGROTOPO, DOSZTIK | Raster vagy vektor | ⚠️ | Opcionális, de javítja az alkalmassági modellt |
| **Földhasználat** | CORINE Land Cover 2018 | Raster 100m | ✅ | Védett és beépített terület maszkja |
| **Közigazgatási határok** | OSM vagy KSH | Vektor (poligon) | ⚠️ | Pilotterület határáért |
| **VTT-referencia-tározók** | OVF, Vásárhelyi-terv | Pont/poligon | ✅ | Validációhoz |
| **Történelmi térképek** | MAPIRE, Arcanum | Scanned raster | ⚠️ | XVIII–XIX. századi mocsarak |

### Lépések

#### 1.1 Copernicus GLO-30 DEM letöltése

```
1. Menj az https://cloud.sdsc.edu oldalra (OpenTopography)
2. Keress "Copernicus GLO-30" DSM-re
3. Adjad meg a pilot terület közegészségügyi kerületeinek határait (WGS84 hosszúság/szélesség)
4. Töltsd le a GeoTIFF-et (~500 MB / tile, attól függ, mekkora a terület)
5. Helyezd a 01_DATA/DEM/ mappába
```

**Pszeudokód Python-ban:**

```python
import rasterio
from rasterio.plot import show
import numpy as np

# DEM beolvasása
dem_wgs84_path = "01_DATA/DEM/Copernicus_GLO30_pilot_area.tif"
with rasterio.open(dem_wgs84_path) as src:
    dem_data = src.read(1)  # 1. sáv = magasság
    dem_meta = src.meta
    print(f"DEM mérete: {dem_data.shape}")
    print(f"Értékek (m): min={dem_data.min()}, max={dem_data.max()}")
    print(f"Vetület: {src.crs}")
```

#### 1.2 Vetület-átalakítás (WGS84 → EOV)

**KRITIKUS:** Az összes raszter és vektor adat ugyanabban az EOV (EPSG:23700) vetületben kell legyen!

```python
from rasterio.warp import calculate_default_transform, reproject, Resampling

# DEM reprojektálása WGS84 → EOV
dem_wgs84_path = "01_DATA/DEM/Copernicus_GLO30.tif"
dem_eov_path = "01_DATA/DEM/Copernicus_GLO30_EOV.tif"

with rasterio.open(dem_wgs84_path) as src:
    transform, width, height = calculate_default_transform(
        src.crs, "EPSG:23700", src.width, src.height, *src.bounds
    )
    
    # Új metadata EOV-hez
    meta = src.meta.copy()
    meta.update({
        'crs': 'EPSG:23700',
        'transform': transform,
        'width': width,
        'height': height
    })
    
    with rasterio.open(dem_eov_path, 'w', **meta) as dst:
        for i in range(1, src.count + 1):
            reproject(
                rasterio.band(src, i),
                rasterio.band(dst, i),
                src_crs=src.crs,
                dst_crs='EPSG:23700',
                resampling=Resampling.bilinear
            )

print(f"✅ EOV-re transzformált DEM: {dem_eov_path}")
```

#### 1.3 DEM vágása a pilot terület határára

```python
from rasterio.mask import mask
import geopandas as gpd

# Pilot terület határainak betöltése (pl. Hármas-Körös vízgyűjtő)
pilot_gpkg = "01_DATA/Pilot_vizgyujto.gpkg"
pilot_shapes = gpd.read_file(pilot_gpkg)
pilot_geom = pilot_shapes.geometry

# DEM vágása a pilot terület határára
dem_eov_path = "01_DATA/DEM/Copernicus_GLO30_EOV.tif"
dem_clipped_path = "01_DATA/DEM/DEM_pilot_clipped.tif"

with rasterio.open(dem_eov_path) as src:
    clipped, transform = mask(src, pilot_geom, crop=True)
    meta = src.meta.copy()
    meta.update({
        "driver": "GTiff",
        "height": clipped.shape[1],
        "width": clipped.shape[2],
        "transform": transform
    })
    
    with rasterio.open(dem_clipped_path, "w", **meta) as dst:
        dst.write(clipped)

print(f"✅ Vágott DEM: {dem_clipped_path}")
```

---

## 2️⃣ DEM ELŐFELDOLGOZÁS – FILL ALGORITMUS

### 🔴 Miért Szükséges?

A nyers DEM-ben "hamis mélyedések" vannak: olyan 1-2 pixeles gödörök, amelyekben a víz nem természetes módon áll meg, hanem számítási hiba vagy mérési zaj miatt. Ha ezeket nem töltöd ki, az algoritmusod ezermilliónyi apró "tározót" talál — teljesen értelmeztelen.

### Megoldás: Planchon–Darboux vagy Wang–Liu Fill Algoritmus

**Ötlet:** Minden pixelnél azt kérdezzük meg: "Ha itt lenne víz, merre folyna le?" Ha a szomszédos pixelek alacsonyabbak vagy egyformák, akkor a víz ott megmarad. Ha a szomszédosok magasabbak, akkor feltöltjük ezt a pixelt addig a szintig, amíg ki nem folyhat.

```python
import numpy as np
from scipy import ndimage
from whitebox.whitebox_tools import WhiteboxTools

# WhiteboxTools: Ez az ajánlott módszer (bevált, gyors, jól tesztelt)
wbt = WhiteboxTools()
wbt.verbose = False

dem_clipped = "01_DATA/DEM/DEM_pilot_clipped.tif"
dem_filled = "02_PROCESSING/DEM_filled.tif"

# Fill Depressions algoritmus futtatása
wbt.fill_depressions(dem_clipped, dem_filled)

print(f"✅ Kitöltött DEM: {dem_filled}")

# Ellenőrzés: mekkora volt az átlagos kitöltés?
with rasterio.open(dem_clipped) as src_orig:
    orig = src_orig.read(1).astype(float)

with rasterio.open(dem_filled) as src_filled:
    filled = src_filled.read(1).astype(float)

diff = filled - orig
print(f"Átlagos kitöltés: {diff[diff > 0].mean():.2f} m")
print(f"Max kitöltés: {diff.max():.2f} m")
```

---

## 3️⃣ TEREPELEMZÉS

### 3.1 Lejtés (Slope)

A lejtés = mennyire meredek egy pont. Lapos terület = vízmegtartás lehetséges, meredek = nem.

```python
from scipy.ndimage import gradient

dem_filled = "02_PROCESSING/DEM_filled.tif"

with rasterio.open(dem_filled) as src:
    dem = src.read(1).astype(float)
    meta = src.meta.copy()
    
    # Lejtés számítása (fok vagy százalék)
    # dy/dx = mennyire változik a magasság
    grad_y, grad_x = gradient(dem, edge_order=2)
    slope_rad = np.arctan(np.sqrt(grad_x**2 + grad_y**2))
    slope_deg = np.degrees(slope_rad)  # Fok
    slope_pct = np.tan(slope_rad) * 100  # Százalék
    
    # Mentés
    slope_path = "02_PROCESSING/slope_deg.tif"
    with rasterio.open(slope_path, 'w', **meta) as dst:
        dst.write(slope_deg, 1)

print(f"✅ Lejtés raszter: {slope_path}")
```

### 3.2 Lefolyásirányt és Vízgyűjtő-akkumuláció

**Flow Direction:** Melyik irányba folyik a víz egy pixelből?
**Flow Accumulation:** Hány pixel vize gyűlik össze egy adott pixelben?

```python
wbt = WhiteboxTools()

dem_filled = "02_PROCESSING/DEM_filled.tif"

# D8 flow direction
flow_dir_path = "02_PROCESSING/flow_direction_d8.tif"
wbt.d8_pointer(dem_filled, flow_dir_path)

# Flow accumulation
flow_acc_path = "02_PROCESSING/flow_accumulation.tif"
wbt.d8_flow_accumulation(dem_filled, flow_acc_path, out_type="specific contributing area")

print(f"✅ Lefolyásirányt: {flow_dir_path}")
print(f"✅ Vízgyűjtő-akkumuláció: {flow_acc_path}")
```

### 3.3 Topográfiai Nedvességi Index (TWI)

TWI = ln(akkumuláció / tan(lejtés))

Jelentés: nagy akku + kis lejtés = magas TWI = vizes terület.

```python
with rasterio.open("02_PROCESSING/slope_deg.tif") as slope_src:
    slope_deg = slope_src.read(1)
    
with rasterio.open("02_PROCESSING/flow_accumulation.tif") as acc_src:
    flow_acc = acc_src.read(1)

# TWI számítása
slope_rad = np.radians(slope_deg)
# Vigyázz: tan(0) = 0, logikailag kellene 0.0001-s küszöb
twi = np.log((flow_acc + 1) / (np.tan(slope_rad) + 0.0001))

# Mentés
twi_path = "02_PROCESSING/TWI.tif"
with rasterio.open("02_PROCESSING/flow_accumulation.tif") as src:
    meta = src.meta
    with rasterio.open(twi_path, 'w', **meta) as dst:
        dst.write(twi, 1)

print(f"✅ TWI: {twi_path}")
```

---

## 4️⃣ TÉRFOGAT-ANALÍZIS – Az Első Saját Algoritmus

### Ötlet: "Hol lehet víz tárolódni?"

Képzelj el egy olyan forgatókönyvet: az eredeti DEM-en egy pixelben az aktuális magasság H₀. Majd egy csatornát készítünk mellette, amely minden mesterséges obstrukciót kitölt. Az új magasság H_filled.

A különbség: **H_filled − H₀** = az az összes víz, amely ebben a pixelben tárolódna.

Ha ezt összeadjuk egy "medence"-nek nevezett összefüggő pixelcsoport összes pixelére, megkapjuk az adott medence **tározó-térfogatát**.

### Pszeudokód

```python
import numpy as np
from scipy.ndimage import label, sum as ndi_sum

dem_orig = "01_DATA/DEM/DEM_pilot_clipped.tif"
dem_filled = "02_PROCESSING/DEM_filled.tif"

with rasterio.open(dem_orig) as src:
    dem_orig_data = src.read(1).astype(float)
    pixel_area = src.res[0] * src.res[1]  # Pl. 30m × 30m = 900 m²
    meta = src.meta

with rasterio.open(dem_filled) as src:
    dem_filled_data = src.read(1).astype(float)

# 1. Mélyedés-mélység pixelenként
depression_depth = dem_filled_data - dem_orig_data
depression_depth[depression_depth < 0] = 0  # Csak pozitív értékek

# 2. Térfogat pixelenként (m³)
volume_per_pixel = depression_depth * pixel_area

# 3. Összefüggő komponensek azonosítása (klaszterezés)
#    Egy "medence" = egy összefüggő pixelcsoport, ahol depression_depth > 0
binary_depressions = depression_depth > 0.1  # 10 cm-es küszöb (zajból)
labeled_depressions, num_features = label(binary_depressions)

print(f"✅ Medencék száma: {num_features}")

# 4. Minden medence térfogatának kiszámítása
basins = []
for basin_id in range(1, num_features + 1):
    basin_mask = labeled_depressions == basin_id
    basin_volume_m3 = volume_per_pixel[basin_mask].sum()
    basin_depth_max = depression_depth[basin_mask].max()
    basin_area_m2 = basin_mask.sum() * pixel_area
    
    # A medence "pour point" megkeresése (legalacsonyabb kifolyási pont)
    basin_coords = np.where(basin_mask)
    pour_point_elevation = dem_filled_data[basin_mask].min()
    
    basins.append({
        'id': basin_id,
        'volume_m3': basin_volume_m3,
        'area_m2': basin_area_m2,
        'max_depth_m': basin_depth_max,
        'pour_point_elevation': pour_point_elevation,
        'num_pixels': basin_mask.sum()
    })

# 5. Medencék rendezése térfogat szerint
basins_sorted = sorted(basins, key=lambda x: x['volume_m3'], reverse=True)

# 6. Mentés CSV-ként
import pandas as pd
df_basins = pd.DataFrame(basins_sorted)
df_basins.to_csv("02_PROCESSING/basins_inventory.csv", index=False)

print(f"✅ Medence-leltár: {len(df_basins)} medence")
print(f"   Top 5 térfogat (m³):")
for i, basin in enumerate(basins_sorted[:5]):
    print(f"     {i+1}. {basin['volume_m3']/1e6:.2f} millió m³")

# 7. Térfogat-térkép mentése (GeoTIFF)
volume_path = "02_PROCESSING/volume_map.tif"
with rasterio.open(volume_path, 'w', **meta) as dst:
    dst.write(volume_per_pixel, 1)

print(f"✅ Térfogat-térkép: {volume_path}")
```

### Vizualizáció QGIS-ben

```
QGIS-ben:
1. Raster → Add Layer → 02_PROCESSING/volume_map.tif
2. Jobbklikk → Properties → Symbology → Singleband pseudocolor
3. Min–Max stretching, megfelelő color ramp (pl. Blues)
4. "Wow, ezek az én természetes medencéim!"
```

---

## 5️⃣ ALKALMASSÁGI MODELL (MCDA + AHP)

### Ötlet: Nem csak térfogat számít

Egy jó helyszínnek több kritériumnak kell megfelelnie:

1. **Térfogat** – Minél nagyobb, annál jobb ✅
2. **Távolság vízfolyástól** – Minél közelebb, annál könnyebb a vízellátás ✅
3. **Talaj beszivárgása** – Nem túl jó (eltűnne a víz), nem túl rossz (felduzzadna) ⚠️
4. **Védettség** – Védett természeti terület? ❌
5. **Beépítettség** – Város közepén? ❌

### 5.1 AHP Súlyozás (Analytic Hierarchy Process)

Nem "örzésből" súlyozunk, hanem Saaty párosítási mátrixával.

**Lépés 1:** Páronként hasonlítunk össze kritériumokat.

|  | Térfogat | Távolság | Talaj | Védettség | Beépítettség |
|---|----------|----------|-------|-----------|--------------|
| **Térfogat** | 1 | 3 | 2 | 5 | 5 |
| **Távolság** | 1/3 | 1 | 1/2 | 3 | 3 |
| **Talaj** | 1/2 | 2 | 1 | 2 | 2 |
| **Védettség** | 1/5 | 1/3 | 1/2 | 1 | 2 |
| **Beépítettség** | 1/5 | 1/3 | 1/2 | 1/2 | 1 |

(Például: "Térfogat 3× fontosabb, mint Távolság", stb.)

**Lépés 2:** Mátrix normalizálása + sajátvektor = súlyok.

```python
import numpy as np

# AHP párosítási mátrix
pairwise = np.array([
    [1,   3,   2,   5,   5],
    [1/3, 1,   1/2, 3,   3],
    [1/2, 2,   1,   2,   2],
    [1/5, 1/3, 1/2, 1,   2],
    [1/5, 1/3, 1/2, 1/2, 1]
])

# Normalizálás
col_sum = pairwise.sum(axis=0)
normalized = pairwise / col_sum

# Sorokátalag = súlyok
weights = normalized.mean(axis=1)
weights = weights / weights.sum()  # 0–1 közé normalizálás

criteria = ['volume', 'distance_stream', 'soil_infiltration', 'protection', 'built_up']
for crit, w in zip(criteria, weights):
    print(f"{crit}: {w:.3f} ({w*100:.1f}%)")

# Pl. eredmény:
# volume: 0.500 (50.0%)
# distance_stream: 0.247 (24.7%)
# soil_infiltration: 0.154 (15.4%)
# protection: 0.061 (6.1%)
# built_up: 0.038 (3.8%)
```

### 5.2 Minden Kritérium Raszterizálása (0–1 Skála)

```python
# 1. TÉRFOGAT (már megvan: volume_map.tif)
with rasterio.open("02_PROCESSING/volume_map.tif") as src:
    volume = src.read(1)

# Normalizálás: 0–1
volume_norm = (volume - volume.min()) / (volume.max() - volume.min())

# 2. TÁVOLSÁG A VÍZFOLYÁSTÓL
# A vízfolyások egy vektorból (pl. OVF shapefile)
# → Raszterizálás → Euclidean distance

from rasterio.features import rasterize
import geopandas as gpd

streams = gpd.read_file("01_DATA/OVF_vizfolyas.shp")
streams_raster_path = "02_PROCESSING/streams_raster.tif"

# Vízfolyások raszterezése
with rasterio.open("02_PROCESSING/volume_map.tif") as template:
    shape = (template.height, template.width)
    transform = template.transform
    meta = template.meta
    
    rasterized = rasterize(streams.geometry, shape=shape, transform=transform, fill=0, default_value=1)
    
    with rasterio.open(streams_raster_path, 'w', **meta) as dst:
        dst.write(rasterized, 1)

# Euclidean távolság
from scipy.ndimage import distance_transform_edt

with rasterio.open(streams_raster_path) as src:
    streams_raster = src.read(1)

distance_to_stream = distance_transform_edt(1 - streams_raster) * 30  # 30m pixel-méret

# Normalizálás: 1 / (1 + távolság_km)  [közelebb = jobb]
distance_to_stream_km = distance_to_stream / 1000
distance_norm = 1 / (1 + distance_to_stream_km)

# 3. TALAJ BESZIVÁRGÁSA
# Az AGROTOPO-ból vesszük vagy egy rasterizált poligon-rétegből
with rasterio.open("01_DATA/talaj_beszivargas.tif") as src:
    infiltration = src.read(1)

# "Jó" beszivárgás = 50–200 mm/nap, rosszabb túl alacsony vagy túl magas
# Függvényfüggés: gussian vagy trapéz
optimal_infiltration = 100  # mm/nap
infiltration_norm = np.exp(-((infiltration - optimal_infiltration) / 50) ** 2)

# 4. VÉDETTSÉG
protected_areas = gpd.read_file("01_DATA/NATURA2000_protected_areas.shp")
protected_raster_path = "02_PROCESSING/protected_raster.tif"

with rasterio.open("02_PROCESSING/volume_map.tif") as template:
    shape = (template.height, template.width)
    transform = template.transform
    meta = template.meta
    
    protected_rasterized = rasterize(protected_areas.geometry, shape=shape, transform=transform, fill=1, default_value=0)
    
    with rasterio.open(protected_raster_path, 'w', **meta) as dst:
        dst.write(protected_rasterized, 1)

with rasterio.open(protected_raster_path) as src:
    protected_raster = src.read(1)

protection_norm = protected_raster  # 1 = jó (nem védett), 0 = rossz (védett)

# 5. BEÉPÍTETTSÉG
# CORINE-ből (111, 112, 123, 124 = beépített terület)
with rasterio.open("01_DATA/CORINE_100m.tif") as src:
    corine = src.read(1)

built_up_classes = [111, 112, 123, 124]
built_up_mask = np.isin(corine, built_up_classes).astype(float)
built_up_norm = 1 - built_up_mask  # 0 = beépített, 1 = jó

# 6. SÚLYOZOTT ÖSSZEADÁS
weights_dict = {
    'volume': 0.500,
    'distance': 0.247,
    'infiltration': 0.154,
    'protection': 0.061,
    'built_up': 0.038
}

suitability = (
    weights_dict['volume'] * volume_norm +
    weights_dict['distance'] * distance_norm +
    weights_dict['infiltration'] * infiltration_norm +
    weights_dict['protection'] * protection_norm +
    weights_dict['built_up'] * built_up_norm
)

# Mentés
suitability_path = "03_OPTIMIZATION/suitability_map.tif"
with rasterio.open("02_PROCESSING/volume_map.tif") as src:
    meta = src.meta
    with rasterio.open(suitability_path, 'w', **meta) as dst:
        dst.write(suitability, 1)

print(f"✅ Alkalmassági térkép: {suitability_path}")
print(f"   Min: {suitability.min():.3f}, Max: {suitability.max():.3f}, Átlag: {suitability.mean():.3f}")
```

---

## 6️⃣ ALGORITMIKUS OPTIMALIZÁLÁS

### 6.1 GREEDY (Mohó) Heurisztika

**Ötlet:** Mindig a legjobb "térfogat per költség" arányú helyszínt választjuk, amíg van költségvetésünk.

```python
import pandas as pd

# Medencék leltára (már megvan)
basins_df = pd.read_csv("02_PROCESSING/basins_inventory.csv")

# Költség-modell (a gyakorlatban: ásott föld volumen)
# Egyszerűsítés: költség ≈ térfogat (m³)
basins_df['cost'] = basins_df['volume_m3'] / 1e6  # millió m³ = "költség egység"

# Alkalmassági pontszám hozzáadása
# A suitability raszter-ből extrahálunk egy értéket minden medencéhez (pl. átlag, max)
with rasterio.open("03_OPTIMIZATION/suitability_map.tif") as src:
    suitability = src.read(1)
    labeled_depressions = ...  # Ez az előző modul outputja

basins_df['suitability_score'] = [
    suitability[labeled_depressions == bid].mean()
    for bid in basins_df['id']
]

# Helyszín-közötti távolság (redundancia-elkerüléshez)
from scipy.spatial.distance import cdist

# Minden medence centroidja
def find_centroid(labeled_array, basin_id):
    coords = np.where(labeled_array == basin_id)
    return (np.mean(coords[0]), np.mean(coords[1]))

centroids = [find_centroid(labeled_depressions, bid) for bid in basins_df['id']]
centroid_distances = cdist(centroids, centroids)

# GREEDY: szoros válogatás
budget = 500  # Millió m³ (költségvetési korlát)
min_distance = 5  # Pixelben = 150m (minimum távolság a helyszínek között)
selected_greedy = []
remaining_budget = budget

# Rendezés: suitability_score / cost (legjobb érték-arány)
basins_df['value_ratio'] = basins_df['suitability_score'] / (basins_df['cost'] + 1)
basins_df_sorted = basins_df.sort_values('value_ratio', ascending=False)

for _, basin in basins_df_sorted.iterrows():
    basin_id = int(basin['id'])
    cost = basin['cost']
    
    # Költségvetés elégséges?
    if cost > remaining_budget:
        continue
    
    # Messze van az összes előzőtől?
    is_far = True
    for selected_id in selected_greedy:
        dist_idx = selected_id - 1  # id → index
        if centroid_distances[basin_id - 1, dist_idx] < min_distance:
            is_far = False
            break
    
    if is_far:
        selected_greedy.append(basin_id)
        remaining_budget -= cost

print(f"✅ GREEDY kiválasztott {len(selected_greedy)} helyszínt")
print(f"   Maradék költségvetés: {remaining_budget:.1f} m³")

# Mentés
greedy_result = pd.DataFrame({
    'basin_id': selected_greedy,
    'total_volume_m3': basins_df[basins_df['id'].isin(selected_greedy)]['volume_m3'].sum(),
    'algorithm': 'greedy'
})
greedy_result.to_csv("03_OPTIMIZATION/result_greedy.csv", index=False)
```

### 6.2 Genetikus Algoritmus

```python
import random
from deap import base, creator, tools, algorithms

# 1. Fitness + Individual definiálása
creator.create("FitnessMulti", base.Fitness, weights=(1.0, -1.0))  # Térfogat MAX, Költség MIN
creator.create("Individual", list, fitness=creator.FitnessMulti)

# 2. Toolbox
toolbox = base.Toolbox()

# Gén: 0 vagy 1 (medence kiválasztva-e?)
toolbox.register("attr_gene", random.randint, 0, 1)

# Egyén: vektor a gének hossza = medencék száma
n_basins = len(basins_df)
toolbox.register(
    "individual", 
    tools.initRepeat, 
    creator.Individual, 
    toolbox.attr_gene, 
    n=n_basins
)

# Populáció
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# 3. Evaluation (fitness függvény)
def evaluate(individual):
    # individual = [0, 1, 0, 1, ..., 1]  (melyik medence kiválasztva)
    selected_basins = [i for i, x in enumerate(individual) if x == 1]
    
    if len(selected_basins) == 0:
        return 0, 1e10  # Nincs semmi = rossz
    
    total_volume = basins_df.iloc[selected_basins]['volume_m3'].sum()
    total_cost = basins_df.iloc[selected_basins]['cost'].sum()
    
    # Távolság-büntetés: ha túl közel vannak egymáshoz
    distance_penalty = 0
    for i, basin_i in enumerate(selected_basins):
        for basin_j in selected_basins[i+1:]:
            if centroid_distances[basin_i, basin_j] < min_distance:
                distance_penalty += 1000  # Nagy büntetés
    
    total_cost += distance_penalty
    
    return (total_volume, total_cost)

toolbox.register("evaluate", evaluate)

# 4. Genetikus operátorok
toolbox.register("mate", tools.cxTwoPoint)
toolbox.register("mutate", tools.mutFlipBit, indpb=0.05)
toolbox.register("select", tools.selTournament, tournsize=3)

# 5. Futtatás
pop = toolbox.population(n=50)
hof = tools.HallOfFame(1)

pop, logbook = algorithms.eaSimple(
    pop, toolbox,
    cxpb=0.7,      # Keresztezésvalószínűség
    mutpb=0.3,     # Mutációs valószínűség
    ngen=100,      # 100 generáció
    halloffame=hof,
    verbose=True
)

# 6. Legjobb megoldás
best_individual = hof[0]
best_selected = [i for i, x in enumerate(best_individual) if x == 1]
best_volume, best_cost = evaluate(best_individual)

print(f"✅ GA legjobb megoldás:")
print(f"   Helyszínek: {len(best_selected)}")
print(f"   Térfogat: {best_volume/1e6:.1f} millió m³")
print(f"   Költség: {best_cost:.1f}")

ga_result = pd.DataFrame({
    'basin_id': best_selected,
    'total_volume_m3': best_volume,
    'algorithm': 'genetic'
})
ga_result.to_csv("03_OPTIMIZATION/result_genetic.csv", index=False)
```

### 6.3 Összehasonlítás

```python
greedy_df = pd.read_csv("03_OPTIMIZATION/result_greedy.csv")
ga_df = pd.read_csv("03_OPTIMIZATION/result_genetic.csv")

comparison = pd.DataFrame({
    'Metric': ['Helyszínszám', 'Össztérfogat (Mm³)', 'Költség', 'Futásidő (s)'],
    'Greedy': [
        len(greedy_df),
        greedy_df['total_volume_m3'].sum() / 1e6,
        ...,
        0.5  # Gyors
    ],
    'Genetikus': [
        len(ga_df),
        ga_df['total_volume_m3'].sum() / 1e6,
        ...,
        15  # Lassabb, de jobb
    ]
})

comparison.to_csv("03_OPTIMIZATION/algorithm_comparison.csv", index=False)
print(comparison)
```

---

## 7️⃣ VALIDÁCIÓ

### 7.1 Vásárhelyi-Terv Összehasonlítása

```python
# VTT-tározók pontos helyeik
vtt_stores = gpd.read_file("01_DATA/VTT_tarozok_actual.shp")

# Algoritmus javaslatai (térkép formában)
result_raster_path = "04_VALIDATION/result_locations_raster.tif"
# (Ezt az előzőben raszterizáltuk)

# Jaccard-index: mennyire fedik egymást?
# J = |A ∩ B| / |A ∪ B|

with rasterio.open(result_raster_path) as src:
    algo_raster = src.read(1) > 0

vtt_rasterized = rasterize(vtt_stores.geometry, shape=algo_raster.shape, ...)
jaccard = (algo_raster & vtt_rasterized).sum() / (algo_raster | vtt_rasterized).sum()

print(f"Jaccard-index (algoritmus vs. VTT): {jaccard:.2%}")
```

### 7.2 Történelmi Térképek

```
# MAPIRE-ből: 1782-es I. katonai felméret raszterkép
# Ebben látszanak a XVIII. századi mocsárak (sötét foltok)

# Digitalizálás:
# 1. QGIS-ben betöltesz a térképet (georeferenced)
# 2. Szakasz rétegen "mocsárak" poligonok
# 3. Raszterizálás

historical_swamps_raster = rasterize(historical_swamps.geometry, shape=algo_raster.shape)

# Korreláció: mai algoritmus vs. történelmi mocsárak
correlation = np.corrcoef(algo_raster.flatten(), historical_swamps_raster.flatten())[0, 1]
print(f"Korreláció (mai vs. történelmi): {correlation:.3f}")
```

---

## 8️⃣ VÉGEREDMÉNY & VIZUALIZÁCIÓ

### Térképek

```python
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.patches import Patch

fig, axes = plt.subplots(2, 2, figsize=(14, 12))

# 1. DEM
ax = axes[0, 0]
im = ax.imshow(dem, cmap='terrain')
ax.set_title('Digitális Domborzatmodell')
plt.colorbar(im, ax=ax, label='Magasság (m)')

# 2. Alkalmassági térkép
ax = axes[0, 1]
im = ax.imshow(suitability, cmap='RdYlGn', norm=Normalize(0, 1))
ax.set_title('Alkalmassági Térkép (MCDA)')
plt.colorbar(im, ax=ax, label='Alkalmasság')

# 3. Javasolt helyszínek (GA)
ax = axes[1, 0]
ax.imshow(dem, cmap='gray', alpha=0.3)
for basin_id in best_selected:
    basin_mask = labeled_depressions == basin_id
    ax.contour(basin_mask, colors='red', linewidths=2)
ax.set_title('Genetikus Algoritmus Javaslatai')

# 4. VTT validáció
ax = axes[1, 1]
ax.imshow(algo_raster.astype(float), cmap='Blues', label='Algoritmus', alpha=0.6)
ax.imshow(vtt_rasterized.astype(float), cmap='Reds', label='VTT tényleges', alpha=0.4)
ax.set_title(f'Validáció (Jaccard: {jaccard:.1%})')
ax.legend()

plt.tight_layout()
plt.savefig("05_VISUALIZATION/results_combined.png", dpi=150, bbox_inches='tight')
plt.show()

print("✅ Térképek mentve: results_combined.png")
```

### Interaktív Folium Térkép

```python
import folium
from folium.plugins import HeatMap

# Alap térkép
m = folium.Map(location=[47.5, 19.5], zoom_start=8, tiles='OpenStreetMap')

# Javasolt helyszínek (zöld jelölők)
for _, basin in basins_df[basins_df['id'].isin(best_selected)].iterrows():
    centroid = find_centroid(labeled_depressions, basin['id'])
    folium.CircleMarker(
        location=[centroid[0], centroid[1]],
        radius=5,
        color='green',
        fill=True,
        popup=f"Térfogat: {basin['volume_m3']/1e6:.1f} Mm³"
    ).add_to(m)

# VTT-tározók (piros jelölők)
for _, store in vtt_stores.iterrows():
    folium.CircleMarker(
        location=[store.geometry.y, store.geometry.x],
        radius=5,
        color='red',
        fill=True,
        popup="VTT tényleges"
    ).add_to(m)

m.save("05_VISUALIZATION/interactive_results.html")
print("✅ Interaktív térkép: interactive_results.html")
```

---

## 🎯 Összefoglalás

| Lépés | Output | Kritikus? |
|-------|--------|----------|
| 1. Adatgyűjtés | DEM, rétegek EOV-ben | ✅ |
| 2. Fill | DEM_filled | ✅ |
| 3. Terepelemzés | slope, flow_acc, TWI | ✅ |
| 4. Térfogat | basins_inventory.csv | ✅ |
| 5. MCDA | suitability_map | ✅ |
| 6. Optimalizálás | result_greedy, result_genetic | ✅ Saját algoritmusok = a lényeg |
| 7. Validáció | Jaccard, korrelációs report | ✅ TDK-t kitünteti |
| 8. Vizualizáció | PNG, HTML térképek | ✅ |

---

**Utolsó frissítés:** 2026.08.18
